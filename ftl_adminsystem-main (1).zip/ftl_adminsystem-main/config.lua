Config = {}
Config.Locale = 'en'
Config.reportCooldown = 60 --seconds
Config.warnMax = 3  --how many warn player can get before getting kicked?
Config.adminRanks = { -- change this as your server ranking ( default are : superadmin | admin | moderator )
				'superadmin',
				'admin',
				'moderator',
				'mod',
				
}

Config.WebHook = "Nastav si webhook"
Config.Name = "Jmeno serveru"
Config.SteamApiKey = ""
Config.DiscordImage = "no asi si nastav fotku"
Config.NearPlayerTime = 500
Config.Command = 'users'
Config.AllowedGroups = {
    'mod',
    'admin',
    'superadmin'
}
Config.TextSize = 2.0
Config.DrawDistance = 1000
